package com.iv.tareabasedatos;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridView;
import android.widget.TextView;

import com.iv.tareabasedatos.adapter.PerfilAdaptador;
import com.iv.tareabasedatos.POJO.Mascota;
import com.mikhaellopez.circularimageview.CircularImageView;

import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 */
public class PerfilFragment extends Fragment {

    private CircularImageView circularImageView;
    private RecyclerView rvPerfil;
    ArrayList <Mascota> mascotas;
    private GridView gridView;
    private TextView tvnombrePerfil;

    public PerfilFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        //Toast.makeText(this.getContext(),"PerfilFragment method",Toast.LENGTH_LONG).show();
        View v = inflater.inflate(R.layout.fragment_perfil, container,false);
        circularImageView = (CircularImageView) v.findViewById(R.id.cimgPerfil);
        // Set Border
        circularImageView.setBorderColor(getResources().getColor(R.color.colorAccent));
        circularImageView.setBorderWidth(10);
// or with custom param
        circularImageView.setShadowRadius(15);
        circularImageView.setShadowColor(getResources().getColor(R.color.colorFondo));

        tvnombrePerfil = (TextView)v.findViewById(R.id.tvNombrePerfil);
        tvnombrePerfil.setText("Sam");
        rvPerfil = (RecyclerView) v.findViewById(R.id.rvPerfil);
        //gridView = (GridView) v.findViewById(R.id.gridviewPerfil);

        GridLayoutManager glm = new GridLayoutManager(getActivity(),3);
        glm.setOrientation(GridLayoutManager.VERTICAL);

        rvPerfil.setLayoutManager(glm);
        inicializarListaMascotas();
        inicializaAdaptador();

        return v;
    }

    public void inicializaAdaptador(){
        PerfilAdaptador adaptador = new PerfilAdaptador(mascotas);
        rvPerfil.setAdapter(adaptador);

    }

    public void inicializarListaMascotas(){
        mascotas = new ArrayList<Mascota>();

        mascotas.add(new Mascota(R.drawable.german_shepherd,"Sam",6,"f"));
        mascotas.add(new Mascota(R.drawable.german_shepherd,"Sam",5,"f"));
        mascotas.add(new Mascota(R.drawable.german_shepherd,"Sam",4,"f"));
        mascotas.add(new Mascota(R.drawable.german_shepherd,"Sam",3,"f"));
        mascotas.add(new Mascota(R.drawable.german_shepherd,"Sam",2,"f"));
        mascotas.add(new Mascota(R.drawable.german_shepherd,"Sam",1,"f"));
        mascotas.add(new Mascota(R.drawable.german_shepherd,"Sam",0,"f"));
        mascotas.add(new Mascota(R.drawable.german_shepherd,"Sam",7,"f"));
        mascotas.add(new Mascota(R.drawable.german_shepherd,"Sam",8,"f"));
        mascotas.add(new Mascota(R.drawable.german_shepherd,"Sam",9,"f"));
        mascotas.add(new Mascota(R.drawable.german_shepherd,"Sam",10,"f"));
        mascotas.add(new Mascota(R.drawable.german_shepherd,"Sam",11,"f"));

        /*
        mascotas.add(new Mascota(R.drawable.corgi,"Corgi",13,'m'));
        mascotas.add(new Mascota(R.drawable.corgi2,"Corgi2",1,'f'));
        mascotas.add(new Mascota(R.drawable.dog_48,"Tomy",5,'m'));
        mascotas.add(new Mascota(R.drawable.dog_50,"Catty",5,'f'));
        mascotas.add(new Mascota(R.drawable.german_shepherd,"Sam",6,'f'));
        mascotas.add(new Mascota(R.drawable.hachiko,"Hatchy",7,'m'));
        */
    }

}
