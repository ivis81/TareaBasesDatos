package com.iv.tareabasedatos.presentador;

/**
 * Created by Ivis on 14/05/2017.
 */

public interface IRecyclerViewFragmentPresenter {

    public void obtenerMascotasBaseDatos();
    public void mostrarMascotasRV();

}
