package com.iv.tareabasedatos.vista_fragment;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.iv.tareabasedatos.adapter.MascotaAdaptador;
import com.iv.tareabasedatos.POJO.Mascota;
import com.iv.tareabasedatos.presentador.IRecyclerViewFragmentPresenter;
import com.iv.tareabasedatos.presentador.RecyclerViewFragmentPresenter;
import com.iv.tareabasedatos.R;

import java.util.ArrayList;

/**
 * Created by Ivis on 03/05/2017.
 */

public class RecyclerViewFragment extends Fragment implements IRecyclerViewFragmentView{


    ArrayList<Mascota> mascotas;
    private RecyclerView rvContactos;
    private IRecyclerViewFragmentPresenter presenter;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_recyclerview, container,false);

        rvContactos = (RecyclerView) v.findViewById(R.id.rvFragmentMascotas);
        presenter = new RecyclerViewFragmentPresenter(this,getContext());
       // inicializarListaMascotas();
        //Toast.makeText(this.getContext(),"RecyclerViewFragment method",Toast.LENGTH_LONG).show();

        return v;
    }
/*
    public void inicializarListaMascotas(){
        mascotas = new ArrayList<Mascota>();

        mascotas.add(new Mascota(R.drawable.corgi,"Corgi",2,'m'));
        mascotas.add(new Mascota(R.drawable.corgi2,"Corgi2",1,'f'));
        mascotas.add(new Mascota(R.drawable.dog_48,"Tomy",5,'m'));
        mascotas.add(new Mascota(R.drawable.dog_50,"Catty",5,'f'));
        mascotas.add(new Mascota(R.drawable.german_shepherd,"Sam",6,'f'));
        mascotas.add(new Mascota(R.drawable.hachiko,"Hatchy",7,'m'));

    }
 */

    @Override
    public void generarLinearLayoutVertical() {
        LinearLayoutManager llm = new LinearLayoutManager(getActivity());
        llm.setOrientation(LinearLayoutManager.VERTICAL);
        rvContactos.setLayoutManager(llm);

    }

    @Override
    public MascotaAdaptador crearAdaptador(ArrayList<Mascota> mascotas) {
        MascotaAdaptador adaptador = new MascotaAdaptador(mascotas,getActivity());

        return adaptador;
    }

    @Override
    public void inicializarAdaptadorRV(MascotaAdaptador adaptador) {
        rvContactos.setAdapter(adaptador);
    }

}
