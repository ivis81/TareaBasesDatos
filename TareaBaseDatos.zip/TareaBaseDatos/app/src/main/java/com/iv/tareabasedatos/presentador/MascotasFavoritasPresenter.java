package com.iv.tareabasedatos.presentador;

import android.content.Context;

import com.iv.tareabasedatos.POJO.Mascota;
import com.iv.tareabasedatos.db.ConstructorMascotas;
import com.iv.tareabasedatos.vista_fragment.IRecyclerViewFragmentView;

import java.util.ArrayList;

/**
 * Created by Ivis on 14/05/2017.
 */

public class MascotasFavoritasPresenter implements IRecyclerViewFragmentPresenter {

    private Context context;
    private IRecyclerViewFragmentView iRecyclerViewFragmentView;
    private ConstructorMascotas constructorMascotas;
    private ArrayList<Mascota> mascotas;
    private ArrayList<Mascota> mascotasfinal;

    public MascotasFavoritasPresenter(IRecyclerViewFragmentView iRecyclerViewFragmentView, Context context) {
        this.iRecyclerViewFragmentView = iRecyclerViewFragmentView;
        this.context = context;
        obtenerMascotasBaseDatos();
    }

    @Override
    public void obtenerMascotasBaseDatos() {
        int x,y;

        constructorMascotas = new ConstructorMascotas(context);
        mascotas = constructorMascotas.obtenerDatos();

        obtenerMascotasTop5(mascotas);  //ORDENAR LAS MASCOTAS PARA MOSTRAR LAS TOP 5

        mostrarMascotasRV();
    }

    @Override
    public void mostrarMascotasRV() {

        iRecyclerViewFragmentView.inicializarAdaptadorRV(iRecyclerViewFragmentView.crearAdaptador(mascotasfinal));
        iRecyclerViewFragmentView.generarLinearLayoutVertical();
    }

    public void obtenerMascotasTop5(ArrayList <Mascota> mascotas){

        int x,y;
        mascotasfinal = new ArrayList<>();
        Mascota mascotasTemp = new Mascota();

        for(x = 0; x < mascotas.size()-1; x++)
        {
            for(y = 0; y < mascotas.size()-1; y++) {
                if (mascotas.get(y).getLike() < mascotas.get(y + 1).getLike()) {

                    mascotasTemp.setId(mascotas.get(y).getId());
                    mascotasTemp.setNombre(mascotas.get(y).getNombre());
                    mascotasTemp.setSexo(mascotas.get(y).getSexo());
                    mascotasTemp.setFoto(mascotas.get(y).getFoto());
                    mascotasTemp.setLike(mascotas.get(y).getLike());

                    mascotas.get(y).equals(mascotas.get(y + 1));
                    mascotas.get(y).setId(mascotas.get(y+1).getId());
                    mascotas.get(y).setNombre(mascotas.get(y+1).getNombre());
                    mascotas.get(y).setSexo(mascotas.get(y+1).getSexo());
                    mascotas.get(y).setFoto(mascotas.get(y+1).getFoto());
                    mascotas.get(y).setLike(mascotas.get(y+1).getLike());

                    mascotas.get(y + 1).setId(mascotasTemp.getId());
                    mascotas.get(y + 1).setNombre(mascotasTemp.getNombre());
                    mascotas.get(y + 1).setSexo(mascotasTemp.getSexo());
                    mascotas.get(y + 1).setFoto(mascotasTemp.getFoto());
                    mascotas.get(y + 1).setLike(mascotasTemp.getLike());
                }
            }
        }

        for(x=0;x<5;x++)
            mascotasfinal.add(mascotas.get(x));

    }

}
