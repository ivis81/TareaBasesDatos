package com.iv.tareabasedatos.db;

import android.content.ContentValues;
import android.content.Context;

import com.iv.tareabasedatos.POJO.Mascota;
import com.iv.tareabasedatos.R;

import java.util.ArrayList;

/**
 * Created by Ivis on 14/05/2017.
 * Interactor
 */

public class ConstructorMascotas {

    private static final int LIKE = 1;
    private Context context;

    public ConstructorMascotas(Context context) {
        this.context = context;
    }

    public ArrayList<Mascota> obtenerDatos(){

        BaseDatos db = new BaseDatos(context);
        if(ConstantesBaseDatos.iniciaDatos) {
            insertarAlgunasMascotas(db);
            ConstantesBaseDatos.iniciaDatos = false;
        }
        return db.obtenerTodasLasMascotas();
    }

    public ArrayList<Mascota> obtenerDatosFavoritos(){

        BaseDatos db = new BaseDatos(context);
        return db.obtenerTodasLasMascotas();
    }

    public void insertarAlgunasMascotas(BaseDatos db){

        ContentValues contentValues = new ContentValues();
            contentValues.put(ConstantesBaseDatos.TABLE_MASCOTAS_NOMBRE, "Corgi");
            contentValues.put(ConstantesBaseDatos.TABLE_MASCOTAS_SEXO, "m");
            contentValues.put(ConstantesBaseDatos.TABLE_MASCOTAS_FOTO, R.drawable.corgi);

            db.insertarMascota(contentValues);

            contentValues = new ContentValues();
            contentValues.put(ConstantesBaseDatos.TABLE_MASCOTAS_NOMBRE, "Corgi2");
            contentValues.put(ConstantesBaseDatos.TABLE_MASCOTAS_SEXO, "f");
            contentValues.put(ConstantesBaseDatos.TABLE_MASCOTAS_FOTO, R.drawable.corgi2);

            db.insertarMascota(contentValues);

            contentValues = new ContentValues();
            contentValues.put(ConstantesBaseDatos.TABLE_MASCOTAS_NOMBRE, "Tomy");
            contentValues.put(ConstantesBaseDatos.TABLE_MASCOTAS_SEXO, "m");
            contentValues.put(ConstantesBaseDatos.TABLE_MASCOTAS_FOTO, R.drawable.dog_48);
            db.insertarMascota(contentValues);

            contentValues = new ContentValues();
            contentValues.put(ConstantesBaseDatos.TABLE_MASCOTAS_NOMBRE, "Catty");
            contentValues.put(ConstantesBaseDatos.TABLE_MASCOTAS_SEXO, "m");
            contentValues.put(ConstantesBaseDatos.TABLE_MASCOTAS_FOTO, R.drawable.dog_50);
            db.insertarMascota(contentValues);

            contentValues = new ContentValues();
            contentValues.put(ConstantesBaseDatos.TABLE_MASCOTAS_NOMBRE, "Sam");
            contentValues.put(ConstantesBaseDatos.TABLE_MASCOTAS_SEXO, "f");
            contentValues.put(ConstantesBaseDatos.TABLE_MASCOTAS_FOTO, R.drawable.german_shepherd);
            db.insertarMascota(contentValues);

            contentValues = new ContentValues();
            contentValues.put(ConstantesBaseDatos.TABLE_MASCOTAS_NOMBRE, "Hatchy");
            contentValues.put(ConstantesBaseDatos.TABLE_MASCOTAS_SEXO, "m");
            contentValues.put(ConstantesBaseDatos.TABLE_MASCOTAS_FOTO, R.drawable.hachiko);
            db.insertarMascota(contentValues);


    }

    public void darLikeMascota(Mascota mascota){

        BaseDatos db = new BaseDatos(context);
        ContentValues contentValues = new ContentValues();

        contentValues.put(ConstantesBaseDatos.TABLE_LIKES_MASCOTA_ID_MASCOTA, mascota.getId());
        contentValues.put(ConstantesBaseDatos.TABLE_LIKES_MASCOTA_NUMERO_LIKES, LIKE);
        db.insertarLikeMascota(contentValues);

    }

    public int obtenerLikesMascota(Mascota mascota){
        BaseDatos db = new BaseDatos(context);
        return db.obtenerLikesMascota(mascota);
    }

}
