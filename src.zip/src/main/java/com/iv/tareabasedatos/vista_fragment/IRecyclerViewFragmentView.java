package com.iv.tareabasedatos.vista_fragment;

import com.iv.tareabasedatos.POJO.Mascota;
import com.iv.tareabasedatos.adapter.MascotaAdaptador;

import java.util.ArrayList;

/**
 * Created by Ivis on 14/05/2017.
 */

public interface IRecyclerViewFragmentView {

    public void generarLinearLayoutVertical();
    public MascotaAdaptador crearAdaptador(ArrayList<Mascota> mascotas);
    public void inicializarAdaptadorRV(MascotaAdaptador adaptador);
}
