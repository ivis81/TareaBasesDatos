package com.iv.tareabasedatos.presentador;

import android.content.Context;

import com.iv.tareabasedatos.POJO.Mascota;
import com.iv.tareabasedatos.db.ConstructorMascotas;
import com.iv.tareabasedatos.vista_fragment.IRecyclerViewFragmentView;

import java.util.ArrayList;

/**
 * Created by Ivis on 14/05/2017.
 */

public class MascotasFavoritasPresenter implements IRecyclerViewFragmentPresenter {

    private Context context;
    private IRecyclerViewFragmentView iRecyclerViewFragmentView;
    private ConstructorMascotas constructorMascotas;
    private ArrayList<Mascota> mascotas;
    private ArrayList<ArrayList<Mascota>> mascotas2;
    public MascotasFavoritasPresenter(IRecyclerViewFragmentView iRecyclerViewFragmentView, Context context) {
        this.iRecyclerViewFragmentView = iRecyclerViewFragmentView;
        this.context = context;
        mostrarMascotasRV();
    }

    @Override
    public void obtenerMascotasBaseDatos() {
        int x,y;
        ArrayList<Mascota> mascotasTemp = new ArrayList<>();

        constructorMascotas = new ConstructorMascotas(context);
        mascotas = constructorMascotas.obtenerDatos();
        for(x = 0; x < mascotas.size()-1; x++)
        {
            for(y = 0; y < mascotas.size()-1; y++) {
                if (mascotas.get(y).getLike() < mascotas.get(y + 1).getLike()) {
                    mascotasTemp.equals(mascotas.get(y));
                    //mascotas.add(mascotas.get(y+1));
                    mascotas.get(y).equals(mascotas.get(y + 1));
                    //mascotas.add(mascotasTemp.get(y));
                    mascotas.get(y + 1).equals(mascotasTemp);
                }
            }

        }

        for(x=0;x<5;x++)
            mascotas2.add(x,mascotas);
        mascotas.equals(mascotas2);
        mostrarMascotasRV();
    }

    @Override
    public void mostrarMascotasRV() {

        iRecyclerViewFragmentView.inicializarAdaptadorRV(iRecyclerViewFragmentView.crearAdaptador(mascotas));
        iRecyclerViewFragmentView.generarLinearLayoutVertical();
    }
}
