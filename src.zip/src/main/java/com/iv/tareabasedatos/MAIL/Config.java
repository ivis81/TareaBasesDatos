package com.iv.tareabasedatos.MAIL;

/**
 * Created by Ivis on 09/05/2017.
 */

public class Config {
    public static final String EMAIL = "yourEmail@gmail.com";
    public static final String PASSWORD = "yourPassword";
}
