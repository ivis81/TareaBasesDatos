package com.iv.tareabasedatos.vista_favoritos;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;

import com.iv.tareabasedatos.POJO.Mascota;
import com.iv.tareabasedatos.adapter.MascotaAdaptador;
import com.iv.tareabasedatos.presentador.IRecyclerViewFragmentPresenter;
import com.iv.tareabasedatos.presentador.RecyclerViewFragmentPresenter;
import com.iv.tareabasedatos.vista_fragment.IRecyclerViewFragmentView;
import com.iv.tareapetagram.R;

import java.util.ArrayList;

/**
 * Created by Ivis on 28/04/2017.
 */

public class MascotasFavoritas extends AppCompatActivity implements IRecyclerViewFragmentView
{
    ArrayList <Mascota> mascotas;
    private RecyclerView listaContactos;
    private Toolbar miActionBar;
    private IRecyclerViewFragmentPresenter presenter;

     @Override
     public void onCreate (Bundle savedInstanceState){
         super.onCreate(savedInstanceState);
         setContentView(R.layout.mascotas_favoritas);

         Toolbar miActionBar = (Toolbar) findViewById(R.id.miActionBarFavoritos);
         setSupportActionBar(miActionBar);
         getSupportActionBar().setDisplayShowTitleEnabled(true);
         getSupportActionBar().setDisplayHomeAsUpEnabled(true);
         getSupportActionBar().setHomeButtonEnabled(true);


         listaContactos = (RecyclerView) findViewById(R.id.rvMascotas);
         presenter = new RecyclerViewFragmentPresenter(this, this);

     }

    @Override
    public void generarLinearLayoutVertical() {
        LinearLayoutManager llm = new LinearLayoutManager(this);
        llm.setOrientation(LinearLayoutManager.VERTICAL);
        listaContactos.setLayoutManager(llm);

    }

    @Override
    public MascotaAdaptador crearAdaptador(ArrayList<Mascota> mascotas) {

        MascotaAdaptador adaptador = new MascotaAdaptador(mascotas,this);
        return adaptador;
    }

    @Override
    public void inicializarAdaptadorRV(MascotaAdaptador adaptador) {
        listaContactos.setAdapter(adaptador);
    }
}
